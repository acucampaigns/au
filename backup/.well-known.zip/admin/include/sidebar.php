<style>


#sidebar-menu ul li a i{ margin-right: 0!important;}</style>

<div class="left side-menu">

                <div class="sidebar-inner slimscrollleft">

                    <!--- Divider -->

                    <div id="sidebar-menu">

                        <ul>

                        	 <li class="treeview">

                              <a href="dashbord.php">

                                <i class="ti-home"></i> <span>Dashboard</span>

                              </a>

                            </li>

                            

                      	 <li class="treeview">

                              <a href="view-product.php">

                                <i class="ti-home"></i> <span>Customer</span>

                              </a>

                            </li>
                            
                             <li class="treeview">

                              <a href="view-product.php?status=1">

                                <i class="ti-home"></i> <span>Payment Success</span>

                              </a>

                            </li>
                            
                             <li class="treeview">

                              <a href="view-product.php?status=0">

                                <i class="ti-home"></i> <span>Payment Reject </span>

                              </a>

                            </li>

                             
						
                          
                        </ul>

                        <div class="clearfix"></div>

                    </div>

                    <div class="clearfix"></div>

                </div>

            </div>

            

            

<div class="content-page">

  <!-- Start content -->

            