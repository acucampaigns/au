<?php	
if(!defined('DIR_ACCESS'))	
	die('Access Denied!');
?>