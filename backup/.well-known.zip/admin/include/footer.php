 <!-- content -->

  <footer class="footer"> &copy; 2017. All rights reserved. </footer>

</div>

</div>

<!-- END wrapper -->

<script>

            var resizefunc = [];

        </script>

<!-- jQuery  -->

<script src="assets/js/jquery.min.js"></script>

<script src="assets/js/bootstrap.min.js"></script>

<script src="assets/js/detect.js"></script>

<script src="assets/js/fastclick.js"></script>

<script src="assets/js/jquery.slimscroll.js"></script>

<script src="assets/js/jquery.blockUI.js"></script>

<script src="assets/js/waves.js"></script>

<script src="assets/js/wow.min.js"></script>

<script src="assets/js/jquery.nicescroll.js"></script>

<script src="assets/js/jquery.scrollTo.min.js"></script>

<script src="assets/js/jquery.core.js"></script>

<script src="assets/js/jquery.app.js"></script>


</body></html>